# Portfolio - MASTER EMMANUEL | White Hat Hacker - Mwanza, Tanzania
L8 Graduate - ID WH-ML-2026-09-005

## Kazi Zangu (Projects)

### 1. My SQLi Scanner (Python)
Nimetengeneza scanner yangu mwenyewe inayofanana na sqlmap.
- Inapima Error-Based SQL Injection
- Code: `my_scanner.py`
- Proof: Imefanikiwa kugundua `[VULNERABLE!]` payload: `' OR '1'='1` kwenye `http://localhost:8000/vuln.php?id=1`

### 2. vulnerable.php vs fixed.php
- `vuln.php` - Website yenye bug (kwa kujifunza)
- `fixed.php` - Nimeitengeneza kuwa salama kwa kutumia Prepared Statements (Best Practice)

### 3. Skills
- SQL Injection Testing (Manual & Automated)
- PHP Secure Coding
- Penetration Testing with Termux (Android)

Contact: Bug Bounty Hunter in Training - Mwanza
